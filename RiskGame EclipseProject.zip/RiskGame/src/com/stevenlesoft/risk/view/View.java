package com.stevenlesoft.risk.view;

import javax.swing.JPanel;

public abstract class View extends JPanel{
	public void loadData()
	{
		// TO BE OVERRIDDEN
	}
}
